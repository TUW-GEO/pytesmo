===========
pytesmo - python Toolbox for the Evaluation of Soil Moisture Observations
===========

pytesmo is a package which aims to provide easy reading functions for soil moisture data, as well as 
functions for comparing these datasets against each other.


Supported Datasets
==================

Soil moisture can be observed by different means, in this version the following datasets are supported.

Remotely sensed products
------------------------

* ASCAT SSM(Surface Soil Moisture)
* ASCAT SWI(Soil Water Index)

insitu obervations
------------------

* Data from the International Soil Moisture Network (ISMN)
.